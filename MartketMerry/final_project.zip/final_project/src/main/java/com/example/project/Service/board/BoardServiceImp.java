package com.example.project.Service.board;

import com.example.project.Entity.board.Board;
import com.example.project.Repository.board.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
@Service
public class BoardServiceImp implements BoardService {

    private final BoardRepository boardRepo;    //보드 레파지토리를 통해 entity 저장

    @Autowired
    public BoardServiceImp(BoardRepository boardRepo) {
        this.boardRepo = boardRepo;
    }

    @Override
    public Long insertBoard(Board board) {
        return boardRepo.save(board).getBoardSeq();
    }

    @Override
    public Board getBoard(Board board) {
        return boardRepo.findById(board.getBoardSeq()).get();
    }

    @Override
    public List<Board> getBoardList(Board board) {
        return (List<Board>) boardRepo.findAll();
    }

    @Override
    public void updateBoard(Board board) {
        Board findBoard = boardRepo.findById(board.getBoardSeq()).get();

        findBoard.setContent(board.getCategory());
        findBoard.setTitle(board.getTitle());
        findBoard.setContent(board.getContent());

        boardRepo.save(findBoard);
    }

    @Override
    public void deleteBoard(Board board) {
        boardRepo.deleteById(board.getBoardSeq());
    }

}
