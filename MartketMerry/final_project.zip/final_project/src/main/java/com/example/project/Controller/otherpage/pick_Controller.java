package com.example.project.Controller.otherpage;

import com.example.project.Entity.Member.Member;
import com.example.project.Service.Member.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(path="/contents")
public class pick_Controller {

    private final MemberService memberService;

    @Autowired
    public pick_Controller(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("member/otherpage/pick")
    public String customerService(Member member, Model model){
        System.out.println("-------GetMapping고객센터--------");
        model.addAttribute("memberId",member);
        return "/contents/myPage/pick";
    }

    @GetMapping("/otherpage/paymentCompleted")
    public String paymentCompleted(Member member, Model model){
        System.out.println("-------GetMapping주문서--------");
        model.addAttribute("memberId",member);
        return "/otherpage/paymentCompleted";
    }


}
