package com.example.project.Service.business;

import org.springframework.stereotype.Service;

@Service
public class BusinessServiceImp implements BusinessService{
}
