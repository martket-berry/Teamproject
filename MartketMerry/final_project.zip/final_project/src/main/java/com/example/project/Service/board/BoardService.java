package com.example.project.Service.board;

import com.example.project.Entity.board.Board;

import java.util.List;

public interface BoardService {
    Long insertBoard(Board board);

    public Board getBoard(Board board);

    List<Board> getBoardList(Board board);

    void updateBoard(Board board);

    void deleteBoard(Board board);
}
