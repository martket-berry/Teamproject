package com.example.project.Service.business;

public interface BusinessService {
}
